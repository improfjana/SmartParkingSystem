 
package com.mycompany.project;

 
import java.util.ArrayList;

// Holds vehicles, tickets, and the parking floor.
public class SmartParkingManager {

    private ArrayList<Vehicle> vehicles;
    private ArrayList<ParkingTicket> tickets;
    private ParkingFloor floor;

    // empty constructor
    public SmartParkingManager() {
        vehicles = new ArrayList<>();
        tickets = new ArrayList<>();
        floor = new ParkingFloor();
    }

    public ArrayList<Vehicle> getVehicles() { return vehicles; }
    public void setVehicles(ArrayList<Vehicle> vehicles) { this.vehicles = vehicles; }

    public ArrayList<ParkingTicket> getTickets() { return tickets; }
    public void setTickets(ArrayList<ParkingTicket> tickets) { this.tickets = tickets; }

    public ParkingFloor getFloor() { return floor; }
    public void setFloor(ParkingFloor floor) { this.floor = floor; }

    public void addVehicle(Vehicle v) {
        if (v != null) {
            vehicles.add(v);
        }
    }

    public void removeVehicle(Vehicle v) {
        vehicles.remove(v);
    }

    /**
     * @param id vehicle id to look up
     * @return matching Vehicle or null
     */
    public Vehicle findVehicleById(String id) {
        for (Vehicle v : vehicles) {
            if (v.getVehicleId().equalsIgnoreCase(id)) {
                return v;
            }
        }
        return null;
    }

    public void addTicket(ParkingTicket t) {
        if (t != null) {
            tickets.add(t);
        }
    }

    public void removeTicket(ParkingTicket t) {
        tickets.remove(t);
    }

    /**
     * @param number ticket number to look up
     * @return matching ParkingTicket or null
     */
    public ParkingTicket findTicketByNumber(String number) {
        for (ParkingTicket t : tickets) {
            if (t.getTicketNumber().equalsIgnoreCase(number)) {
                return t;
            }
        }
        return null;
    }

    public void displayAllVehicles() {
        if (vehicles.size() == 0) {
            System.out.println("No vehicles registered.");
            return;
        }
        for (Vehicle v : vehicles) {
            System.out.println(v);
            System.out.println("------------------------------------------");
        }
    }

    public void displayAllTickets() {
        if (tickets.size() == 0) {
            System.out.println("No tickets issued.");
            return;
        }
        for (ParkingTicket t : tickets) {
            System.out.println(t);
            System.out.println("==========================================");
        }
    }

    public void displayElectricCars() {
        boolean found = false;
        for (Vehicle v : vehicles) {
            if (v instanceof ElectricCar) {
                System.out.println(v);
                System.out.println("------------------------------------------");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No electric cars registered.");
        }
    }

    public void showFeaturesAll() {
        if (vehicles.size() == 0) {
            System.out.println("No vehicles registered.");
            return;
        }
        for (Vehicle v : vehicles) {
            v.showFeatures();
        }
    }

    /**
     * @param keyword case-insensitive owner-name fragment
     * @return list of matching vehicles
     */
    public ArrayList<Vehicle> searchVehicleByOwner(String keyword) {
        ArrayList<Vehicle> results = new ArrayList<>();
        String key = keyword.toLowerCase();
        for (Vehicle v : vehicles) {
            if (v.getOwnerName().toLowerCase().contains(key)) {
                results.add(v);
            }
        }
        return results;
    }

    /**
     * @param hours hours used for each vehicle's fee
     * @return summed parking fees across all vehicles
     */
    public double calculateTotalFees(int hours) {
        double total = 0.0;
        for (Vehicle v : vehicles) {
            total += v.calculateParkingFee(hours);
        }
        return total;
    }
}

