package com.mycompany.project;

public class Car extends Vehicle {

    private int numberOfDoors;
    private boolean hasAirConditioning;
    private static final double CAR_RATE = 5.0;

    public Car(String vehicleId, String licensePlate, String ownerName, int parkingHours, String spotId, double minimumFee, ParkingTicket ticket, int numberOfDoors, boolean hasAirConditioning) {

        super(vehicleId, licensePlate, ownerName, parkingHours, spotId, minimumFee, ticket);
        setNumberOfDoors(numberOfDoors);
        setHasAirConditioning(hasAirConditioning);
    }

    // empty constructor
    public Car() {
        this("", "", "", 0, "", 0.0, null, 0, false);
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        if (numberOfDoors < 0) {
            throw new IllegalArgumentException("Number of doors cannot be negative");
        }
        this.numberOfDoors = numberOfDoors;
    }

    public boolean isHasAirConditioning() {
        return hasAirConditioning;
    }

    public void setHasAirConditioning(boolean hasAirConditioning) {
        this.hasAirConditioning = hasAirConditioning;
    }

    @Override
    public double getParkingRate() {
        return CAR_RATE;
    }

    @Override
    public String getVehicleType() {
        return "Car";
    }

    @Override
    public void showFeatures() {
        System.out.printf("Car features: %d doors, A/C %b%n", numberOfDoors, hasAirConditioning);
    }

    @Override
    public String toString() {
        return String.format("%s%nDoors: %d%nAir Conditioning: %b", super.toString(), numberOfDoors, hasAirConditioning);
    }
}
