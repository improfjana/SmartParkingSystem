 
package com.mycompany.project;
 

// NetBeans entry point — delegates to Main.
public class SmartParkingSystem {

    public static void main(String[] args) {
        Main.main(args);
    }
}
