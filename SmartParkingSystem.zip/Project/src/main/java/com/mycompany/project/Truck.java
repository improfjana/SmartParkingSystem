package com.mycompany.project;

 
public class Truck extends Vehicle {

    private double loadCapacity;
    private static final double TRUCK_RATE = 10.0;
 
    public Truck(String vehicleId, String licensePlate, String ownerName,
                 int parkingHours, String spotId, double minimumFee,
                 ParkingTicket ticket, double loadCapacity) {
        super(vehicleId, licensePlate, ownerName, parkingHours, spotId, minimumFee, ticket);
        setLoadCapacity(loadCapacity);
    }

    // empty constructor
    public Truck() {
        this("", "", "", 0, "", 0.0, null, 0.0);
    }

    public double getLoadCapacity() { return loadCapacity; }
    public void setLoadCapacity(double loadCapacity) {
        if (loadCapacity < 0) throw new IllegalArgumentException("Load capacity cannot be negative");
        this.loadCapacity = loadCapacity;
    }

    @Override
    public double getParkingRate() { return TRUCK_RATE; }

    @Override
    public String getVehicleType() { return "Truck"; }

    @Override
    public void showFeatures() {
        System.out.printf("Truck features: load capacity %.2f tons%n", loadCapacity);
    }

    @Override
    public String toString() {
        return String.format("%s%nLoad Capacity: %.2f tons", super.toString(), loadCapacity);
    }
}

