package com.mycompany.project;

public interface ParkingOperations {

    public static final double MAX_PARKING_HOURS = 24.0;

    public abstract double calculateParkingFee(int hours);

    public abstract String getParkingInfo();
}

