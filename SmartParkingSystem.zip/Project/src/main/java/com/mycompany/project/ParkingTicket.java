package com.mycompany.project;

 
public class ParkingTicket implements ParkingOperations {

    private final String ticketNumber;
    private Vehicle vehicle;
    private ParkingSpot spot;
    private String issueDateTime;

     
    public ParkingTicket(Vehicle vehicle, ParkingSpot spot, String issueDateTime) {
        this.ticketNumber = String.format("T-%d", generateId());
        setVehicle(vehicle);
        setSpot(spot);
        setIssueDateTime(issueDateTime);
    }

    // empty constructor
    public ParkingTicket() {
        this(null, null, "");
    }

    public String getTicketNumber() { return ticketNumber; }

    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }

    public ParkingSpot getSpot() { return spot; }
    public void setSpot(ParkingSpot spot) { this.spot = spot; }

    public String getIssueDateTime() { return issueDateTime; }
    public void setIssueDateTime(String issueDateTime) { this.issueDateTime = issueDateTime.trim(); }

    private int generateId() {
        int min = 1000;
        int max = 9999;
        return (int)(Math.random() * (max - min + 1)) + min;
    }

    /**
     * @param hours hours parked
     * @return fee delegated to the held vehicle, or 0 if no vehicle attached
     */
    @Override
    public double calculateParkingFee(int hours) {
        if (vehicle == null) {
            return 0.0;
        }
        return vehicle.calculateParkingFee(hours);
    }

    @Override
    public String getParkingInfo() {
        String vehiclePart = (vehicle == null) ? "no vehicle" : vehicle.getParkingInfo();
        String spotPart = (spot == null) ? "no spot" : "spot " + spot.getSpotId();
        return String.format("Ticket %s on %s — %s, %s",
            ticketNumber, issueDateTime, vehiclePart, spotPart);
    }

    public String getTicketSummary() {
        String vehiclePart = (vehicle == null)
            ? "(no vehicle)"
            : vehicle.getVehicleType() + " " + vehicle.getVehicleId();
        String spotPart = (spot == null) ? "(no spot)" : spot.getSpotId();
        return String.format("Ticket %s | Issued: %s | Vehicle: %s | Spot: %s",
            ticketNumber, issueDateTime, vehiclePart, spotPart);
    }

    @Override
    public String toString() {
        String vehicleStr = (vehicle == null)
            ? "(none)"
            : vehicle.getVehicleType() + " #" + vehicle.getVehicleId();
        String spotStr = (spot == null) ? "(none)" : spot.getSpotId();
        return String.format("Ticket Number: %s%nIssue Date: %s%nVehicle: %s%nSpot: %s",
            ticketNumber, issueDateTime, vehicleStr, spotStr);
    }
}

