package com.mycompany.project;

 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static SmartParkingManager system = new SmartParkingManager();
    public static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        fillList();
        System.out.println("**** Welcome To Smart Parking System ****");

        int choice = 0;
        do {
            try {
                menu();
                choice = Integer.parseInt(input.nextLine().trim());
                switch (choice) {
                    case 1:  addVehicle();                       break;
                    case 2:  removeVehicle();                    break;
                    case 3:  system.displayAllVehicles();        break;
                    case 4:  system.displayElectricCars();       break;
                    case 5:  showElectricCarsNeedingCharger();   break;
                    case 6:  system.showFeaturesAll();           break;
                    case 7:  searchVehicleByOwner();             break;
                    case 8:  calculateTotalFees();               break;
                    case 9:  issueTicket();                      break;
                    case 10: system.displayAllTickets();         break;
                    case 11: growSpots();                        break;
                    case 12: shrinkSpots();                      break;
                    case 13: displayAllSpots();                  break;
                    case 14: searchSpotById();                   break;
                    case 15: showFloorInfo();                    break;
                    case 16: writeText();                        break;
                    case 17: readText();                         break;
                    case 18: launchGUI();                        break;
                    case 19: System.out.println("Thank you!");   break;
                    default: System.out.println("Invalid option!");
                }
            } catch (InputMismatchException ex) {
                System.err.println("Invalid input");
                input.nextLine();
            } catch (NumberFormatException ex) {
                System.err.println("Please enter a number.");
            } catch (IllegalArgumentException ex) {
                System.out.println("Error: " + ex.getMessage());
            } catch (NullPointerException ex) {
                System.err.println(ex);
            } catch (ClassCastException ex) {
                System.err.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.err.println(ex);
            } catch (Exception ex) {
                System.err.println(ex);
            }
        } while (choice != 19);
    }

    // Prints the menu.
    public static void menu() {
        System.out.print(
            "\n1.  Add Vehicle.\n"
          + "2.  Remove Vehicle.\n"
          + "3.  Display All Vehicles.\n"
          + "4.  Display Electric Cars.\n"
          + "5.  Show Electric Cars Needing Charger.\n"
          + "6.  Show All Vehicle Features.\n"
          + "7.  Search Vehicle by Owner.\n"
          + "8.  Calculate Total Parking Fees.\n"
          + "9.  Issue Parking Ticket.\n"
          + "10. Display All Tickets.\n"
          + "11. Grow Spots Array (Add Spot).\n"
          + "12. Shrink Spots Array (Remove Spot).\n"
          + "13. Display All Spots.\n"
          + "14. Search Spot by ID.\n"
          + "15. Show Floor Info.\n"
          + "16. Save Vehicles to File.\n"
          + "17. Load Vehicles from File.\n"
          + "18. GUI.\n"
          + "19. Exit.\n"
          + ">> ");
    }

    // Fills the system with sample vehicles, spots, and a ticket.
    private static void fillList() {
        ParkingSpot s1 = new ParkingSpot("A01", "S-001", "Ground", false);
        ParkingSpot s2 = new ParkingSpot("A02", "S-002", "Ground", true);
        ParkingSpot s3 = new ParkingSpot("B01", "S-003", "First", false);
        ParkingSpot[] initial = { s1, s2, s3 };
        ParkingFloor floor = new ParkingFloor("Ground", 10, initial);
        system.setFloor(floor);

        system.addVehicle(new Car("V-001", "ABC1234", "Ali Mohammad", 2, "S-001", 5.0, null, 4, true));
        system.addVehicle(new ElectricCar("V-002", "XYZ9876", "Lamar Saud", 3, "S-002", 7.0, null, 2, true, 75));
        system.addVehicle(new Motorcycle("V-003", "MOTO50", "Khalid Said", 1, "S-003", 3.0, null, false));
        system.addVehicle(new Truck("V-004", "TRK0001", "Faisal Bin", 5, "", 10.0, null, 12.5));

        Vehicle v1 = system.findVehicleById("V-001");
        ParkingSpot spot1 = system.getFloor().findSpotById("S-001");
        system.addTicket(new ParkingTicket(v1, spot1, "01/05/2026"));
    }

    private static void addVehicle() {
        System.out.println("Pick vehicle type:");
        System.out.println("  1. Car");
        System.out.println("  2. Electric Car");
        System.out.println("  3. Motorcycle");
        System.out.println("  4. Truck");
        int type = readIntInRange("Type (1-4): ", 1, 4);

        String id = readNonEmptyString("Vehicle ID: ");
        String plate = readPlate("License Plate (6-8 uppercase letters/digits): ");
        String owner = readName("Owner Name: ");
        int hours = readNonNegativeInt("Parking Hours: ");
        String spotId = readNonEmptyString("Assigned Spot ID: ");
        double minFee = readNonNegativeDouble("Minimum Fee: ");

        switch (type) {
            case 1: {
                int doors = readNonNegativeInt("Number of Doors: ");
                boolean ac = readBoolean("Has Air Conditioning (true/false): ");
                system.addVehicle(new Car(id, plate, owner, hours, spotId, minFee, null, doors, ac));
                break;
            }
            case 2: {
                int doors = readNonNegativeInt("Number of Doors: ");
                boolean ac = readBoolean("Has Air Conditioning (true/false): ");
                int battery = readNonNegativeInt("Battery Capacity (kWh): ");
                system.addVehicle(new ElectricCar(id, plate, owner, hours, spotId, minFee, null, doors, ac, battery));
                break;
            }
            case 3: {
                boolean sidecar = readBoolean("Has Sidecar (true/false): ");
                system.addVehicle(new Motorcycle(id, plate, owner, hours, spotId, minFee, null, sidecar));
                break;
            }
            case 4: {
                double load = readNonNegativeDouble("Load Capacity (tons): ");
                system.addVehicle(new Truck(id, plate, owner, hours, spotId, minFee, null, load));
                break;
            }
        }
        System.out.println("Vehicle added.");
    }

    private static void removeVehicle() {
        String id = readNonEmptyString("Vehicle ID to remove: ");
        Vehicle v = system.findVehicleById(id);
        if (v == null) {
            System.out.println("Vehicle not found.");
            return;
        }
        System.out.print("Confirm remove? (Y/N): ");
        if (input.nextLine().trim().equalsIgnoreCase("Y")) {
            system.removeVehicle(v);
            System.out.println("Vehicle removed.");
        } else {
            System.out.println("Cancelled.");
        }
    }

    // Demonstrates instanceof + downcast to call the unique ElectricCar.needsCharger() method.
    private static void showElectricCarsNeedingCharger() {
        boolean found = false;
        for (Vehicle v : system.getVehicles()) {
            if (v instanceof ElectricCar) {
                ElectricCar ec = (ElectricCar) v;
                if (ec.needsCharger()) {
                    System.out.println(ec);
                    System.out.println("------------------------------------------");
                    found = true;
                }
            }
        }
        if (!found) {
            System.out.println("No electric cars need a charger.");
        }
    }

    private static void searchVehicleByOwner() {
        String keyword = readNonEmptyString("Owner name keyword: ");
        ArrayList<Vehicle> results = system.searchVehicleByOwner(keyword);
        if (results.size() == 0) {
            System.out.println("No vehicles match.");
            return;
        }
        for (Vehicle v : results) {
            System.out.println(v);
            System.out.println("------------------------------------------");
        }
    }

    private static void calculateTotalFees() {
        int hours = readPositiveInt("Hours to bill each vehicle: ");
        double total = system.calculateTotalFees(hours);
        System.out.printf("Total fees: %.2f%n", total);
    }

    private static void issueTicket() {
        String vid = readNonEmptyString("Vehicle ID: ");
        Vehicle v = system.findVehicleById(vid);
        if (v == null) {
            System.out.println("Vehicle not found.");
            return;
        }
        String sid = readNonEmptyString("Spot ID: ");
        ParkingSpot spot = system.getFloor().findSpotById(sid);
        if (spot == null) {
            System.out.println("Spot not found.");
            return;
        }
        String date = readDate("Issue Date (DD/MM/YYYY): ");

        ParkingTicket t = new ParkingTicket(v, spot, date);
        system.addTicket(t);
        spot.setReserved(true);
        v.setTicket(t);
        System.out.println("Ticket issued: " + t.getTicketNumber());
    }

    private static void growSpots() {
        String code = readNonEmptyString("Spot Code: ");
        String id = readNonEmptyString("Spot ID: ");
        String level = readLocation("Level: ");
        boolean reserved = readBoolean("Reserved (true/false): ");
        ParkingSpot newSpot = new ParkingSpot(code, id, level, reserved);

        ParkingFloor floor = system.getFloor();
        ParkingSpot[] current = floor.getSpots();
        int len = (current == null) ? 0 : current.length;
        ParkingSpot[] grown = new ParkingSpot[len + 1];
        for (int i = 0; i < len; i++) {
            grown[i] = current[i];
        }
        grown[len] = newSpot;
        floor.setSpots(grown);
        System.out.println("Spot added. Array length now: " + grown.length);
    }

    private static void shrinkSpots() {
        ParkingFloor floor = system.getFloor();
        ParkingSpot[] current = floor.getSpots();
        if (current == null || current.length == 0) {
            System.out.println("Spots array is already empty.");
            return;
        }
        for (int i = 0; i < current.length; i++) {
            System.out.println("[" + i + "] " + current[i].getSpotId() + " (" + current[i].getSpotCode() + ")");
        }
        int idx = readIntInRange("Index to remove: ", 0, current.length - 1);
        ParkingSpot[] shrunk = new ParkingSpot[current.length - 1];
        int w = 0;
        for (int i = 0; i < current.length; i++) {
            if (i != idx) {
                shrunk[w++] = current[i];
            }
        }
        floor.setSpots(shrunk);
        System.out.println("Spot removed. Array length now: " + shrunk.length);
    }

    private static void displayAllSpots() {
        ParkingSpot[] spots = system.getFloor().getSpots();
        if (spots == null || spots.length == 0) {
            System.out.println("No spots in the floor.");
            return;
        }
        for (int i = 0; i < spots.length; i++) {
            System.out.println(spots[i]);
            System.out.println("------------------------------------------");
        }
    }

    private static void searchSpotById() {
        String id = readNonEmptyString("Spot ID to find: ");
        ParkingSpot[] spots = system.getFloor().getSpots();
        if (spots == null || spots.length == 0) {
            System.out.println("No spots to search.");
            return;
        }
        for (int i = 0; i < spots.length; i++) {
            if (spots[i] != null && spots[i].getSpotId().equalsIgnoreCase(id)) {
                System.out.println("Found at index " + i + ":");
                System.out.println(spots[i]);
                return;
            }
        }
        System.out.println("Spot not found.");
    }

    private static void showFloorInfo() {
        System.out.println(system.getFloor());
    }

    private static void launchGUI() {
        try {
            GUI.main(null);
        } catch (Exception ex) {
            System.err.println("Could not launch GUI: " + ex.getMessage());
        }
    }

    // ========================================================================
    // Validation helpers â€” bottom of Main.
    // ========================================================================

    private static int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() > 0;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                if (c < '0' || c > '9') {
                    ok = false;
                }
            }
            if (ok) {
                int n = Integer.parseInt(line);
                if (n > 0) {
                    return n;
                }
            }
            System.out.println("Please enter a positive integer.");
        }
    }

    private static int readNonNegativeInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() > 0;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                if (c < '0' || c > '9') {
                    ok = false;
                }
            }
            if (ok) {
                return Integer.parseInt(line);
            }
            System.out.println("Please enter a non-negative integer.");
        }
    }

    private static int readIntInRange(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() > 0;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                if (c < '0' || c > '9') {
                    ok = false;
                }
            }
            if (ok) {
                int n = Integer.parseInt(line);
                if (n >= min && n <= max) {
                    return n;
                }
            }
            System.out.println("Please enter an integer between " + min + " and " + max + ".");
        }
    }

    private static double readNonNegativeDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() > 0;
            int dots = 0;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                if (c == '.') {
                    dots++;
                    if (dots > 1) {
                        ok = false;
                    }
                } else if (c < '0' || c > '9') {
                    ok = false;
                }
            }
            if (ok) {
                double d = Double.parseDouble(line);
                if (d >= 0) {
                    return d;
                }
            }
            System.out.println("Please enter a non-negative number.");
        }
    }

    private static boolean readBoolean(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            if (line.equalsIgnoreCase("true")) {
                return true;
            }
            if (line.equalsIgnoreCase("false")) {
                return false;
            }
            System.out.println("Please enter true or false.");
        }
    }

    private static String readName(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() >= 2 && line.length() <= 50;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                boolean letter = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
                boolean space = (c == ' ');
                if (!letter && !space) {
                    ok = false;
                }
            }
            if (ok) {
                return line;
            }
            System.out.println("Name must be 2-50 letters and spaces only.");
        }
    }

    private static String readPlate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim().toUpperCase();
            boolean ok = line.length() >= 6 && line.length() <= 8;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                boolean upper = (c >= 'A' && c <= 'Z');
                boolean digit = (c >= '0' && c <= '9');
                if (!upper && !digit) {
                    ok = false;
                }
            }
            if (ok) {
                return line;
            }
            System.out.println("Plate must be 6-8 uppercase letters and digits only.");
        }
    }

    private static String readLocation(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() >= 2 && line.length() <= 100;
            for (int i = 0; ok && i < line.length(); i++) {
                char c = line.charAt(i);
                boolean letter = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
                boolean digit = (c >= '0' && c <= '9');
                boolean space = (c == ' ');
                if (!letter && !digit && !space) {
                    ok = false;
                }
            }
            if (ok) {
                return line;
            }
            System.out.println("Location must be 2-100 letters/digits/spaces.");
        }
    }

    private static String readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            boolean ok = line.length() == 10
                      && line.charAt(2) == '/'
                      && line.charAt(5) == '/';
            for (int i = 0; ok && i < line.length(); i++) {
                if (i == 2 || i == 5) {
                    continue;
                }
                char c = line.charAt(i);
                if (c < '0' || c > '9') {
                    ok = false;
                }
            }
            if (ok) {
                int day = Integer.parseInt(line.substring(0, 2));
                int month = Integer.parseInt(line.substring(3, 5));
                int year = Integer.parseInt(line.substring(6, 10));
                int maxDay = 31;
                if (month == 4 || month == 6 || month == 9 || month == 11) {
                    maxDay = 30;
                }
                if (month == 2) {
                    maxDay = 29;
                }
                if (month >= 1 && month <= 12
                        && day >= 1 && day <= maxDay
                        && year >= 2020 && year <= 2030) {
                    return line;
                }
            }
            System.out.println("Date must be DD/MM/YYYY, valid, year 2020-2030.");
        }
    }

    private static String readNonEmptyString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            if (line.length() > 0) {
                return line;
            }
            System.out.println("Value cannot be empty.");
        }
    }

    /**
     * Saves all vehicles to the text file.
     */
    public static void writeText() {
        try {
            Formatter output = new Formatter("parking.txt");
            if (system.getVehicles().isEmpty()) {
                System.out.println("No vehicles yet.");
            } else {
                for (Vehicle ele : system.getVehicles()) {
                    output.format(ele.toString() + "\n");
                    output.format("\n---------------------------------------------\n");
                }
                System.out.println("All vehicles saved to the text file parking.txt");
            }
            output.close();
        } catch (SecurityException ex) {
            System.err.println("You do not have write access to this file.");
            System.err.println(ex);
        } catch (FileNotFoundException ex) {
            System.err.println("Error opening or creating file.");
            System.err.println(ex);
        }
    }

    /**
     * Reads the text file line by line and prints each line.
     */
    public static void readText() {
        try {
            Scanner fileIn = new Scanner(new File("parking.txt"));
            while (fileIn.hasNextLine()) {
                System.out.println(fileIn.nextLine());
            }
            fileIn.close();
        } catch (FileNotFoundException ex) {
            System.err.println("Error opening or creating file.");
            System.err.println(ex);
        } catch (NoSuchElementException ex) {
            System.err.println("File improperly formed.");
            System.err.println(ex);
        } catch (IllegalStateException ex) {
            System.err.println("Error reading from file.");
            System.err.println(ex);
        }
    }
}

