package com.mycompany.project;

public class Motorcycle extends Vehicle {

    private boolean hasSidecar;
    private static final double MOTORCYCLE_RATE = 3.0;

    public Motorcycle(String vehicleId, String licensePlate, String ownerName, int parkingHours, String spotId, double minimumFee, ParkingTicket ticket, boolean hasSidecar) {

        super(vehicleId, licensePlate, ownerName, parkingHours, spotId, minimumFee, ticket);
        setHasSidecar(hasSidecar);
    }

    // empty constructor
    public Motorcycle() {
        this("", "", "", 0, "", 0.0, null, false);
    }

    public boolean isHasSidecar() {
        return hasSidecar;
    }

    public void setHasSidecar(boolean hasSidecar) {
        this.hasSidecar = hasSidecar;
    }

    @Override
    public double getParkingRate() {
        return MOTORCYCLE_RATE;
    }

    @Override
    public String getVehicleType() {
        return "Motorcycle";
    }

    @Override
    public void showFeatures() {
        System.out.printf("Motorcycle features: sidecar %b%n", hasSidecar);
    }

    @Override
    public String toString() {
        return String.format("%s%nHas Sidecar: %b", super.toString(), hasSidecar);
    }
}
