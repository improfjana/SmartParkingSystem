package com.mycompany.project;

public class ElectricCar extends Car {

    private int batteryCapacity;
    private static final double ELECTRIC_CAR_RATE = 7.0;

    public ElectricCar(String vehicleId, String licensePlate, String ownerName, int parkingHours, String spotId, double minimumFee, ParkingTicket ticket, int numberOfDoors, boolean hasAirConditioning, int batteryCapacity) {

        super(vehicleId, licensePlate, ownerName, parkingHours, spotId, minimumFee,
                ticket, numberOfDoors, hasAirConditioning);
        setBatteryCapacity(batteryCapacity);
    }

    // empty constructor
    public ElectricCar() {
        this("", "", "", 0, "", 0.0, null, 0, false, 0);
    }

    public int getBatteryCapacity() {
        return batteryCapacity;
    }

    public void setBatteryCapacity(int batteryCapacity) {
        if (batteryCapacity < 0) {
            throw new IllegalArgumentException("Battery capacity cannot be negative");
        }
        this.batteryCapacity = batteryCapacity;
    }

    // Unique method used in Main via instanceof + downcast.
    public boolean needsCharger() {
        return batteryCapacity > 0;
    }

    @Override
    public double getParkingRate() {
        return ELECTRIC_CAR_RATE;
    }

    @Override
    public String getVehicleType() {
        return "Electric Car";
    }

    @Override
    public void showFeatures() {
        System.out.printf("Electric car features: battery %d kWh, %d doors, needs charger %b%n",
                batteryCapacity, getNumberOfDoors(), needsCharger());
    }

    @Override
    public String toString() {
        return String.format("%s%nBattery Capacity: %d kWh", super.toString(), batteryCapacity);
    }
}
