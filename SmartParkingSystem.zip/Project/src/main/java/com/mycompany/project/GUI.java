 
package com.mycompany.project;
  
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GUI extends Application {

    @Override
    public void start(Stage primaryStage) {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);
        grid.setStyle("-fx-background-color: #E6F0FA;");

        Label title = new Label("--- Smart Parking System ---");
        title.setFont(Font.font(20));
        grid.add(title, 0, 0, 2, 1);

        Label idLabel = new Label("Vehicle ID:");
        TextField idField = new TextField();
        grid.add(idLabel, 0, 1);
        grid.add(idField, 1, 1);

        Label plateLabel = new Label("License Plate:");
        TextField plateField = new TextField();
        grid.add(plateLabel, 0, 2);
        grid.add(plateField, 1, 2);

        Label ownerLabel = new Label("Owner Name:");
        TextField ownerField = new TextField();
        grid.add(ownerLabel, 0, 3);
        grid.add(ownerField, 1, 3);

        Label hoursLabel = new Label("Parking Hours:");
        TextField hoursField = new TextField();
        grid.add(hoursLabel, 0, 4);
        grid.add(hoursField, 1, 4);

        Button addButton = new Button("Add Car");
        Button showButton = new Button("Show All Vehicles");
        addButton.setStyle("-fx-background-color: #B3D4FC; -fx-padding: 8px 15px;");
        showButton.setStyle("-fx-background-color: #B3D4FC; -fx-padding: 8px 15px;");
        grid.add(addButton, 0, 5);
        grid.add(showButton, 1, 5);

        TextArea outputArea = new TextArea();
        outputArea.setWrapText(true);
        outputArea.setEditable(false);
        outputArea.setPrefHeight(200);
        grid.add(outputArea, 0, 6, 2, 1);

        addButton.setOnAction(e -> {
            try {
                String id = idField.getText().trim();
                String plate = plateField.getText().trim().toUpperCase();
                String owner = ownerField.getText().trim();
                int hours = Integer.parseInt(hoursField.getText().trim());
                Car c = new Car(id, plate, owner, hours, "", 5.0, null, 4, true);
                Main.system.addVehicle(c);
                outputArea.setText("Car added: " + id);
            } catch (Exception ex) {
                outputArea.setText("Error: please enter valid values.");
            }
        });

        showButton.setOnAction(e -> {
            String s = "";
            for (Vehicle v : Main.system.getVehicles()) {
                s += v.toString() + "\n------------------\n";
            }
            if (s.length() == 0) {
                s = "No vehicles registered.";
            }
            outputArea.setText(s);
        });

        Scene scene = new Scene(grid, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Smart Parking System");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

