package com.mycompany.project;

 
 public class ParkingSpot {

    private String spotCode;
    private final String spotId;
    private String level;
    private boolean reserved;
    private final String spotRef;
    private static int count;

    
    public ParkingSpot(String spotCode, String spotId, String level, boolean reserved) {
        setSpotCode(spotCode);
        this.spotId = spotId;
        setLevel(level);
        setReserved(reserved);
        this.spotRef = generateSpotRef();
        count++;
    }

    // empty constructor
    public ParkingSpot() {
        this("", "", "", false);
    }

    public String getSpotCode() { return spotCode; }
    public void setSpotCode(String spotCode) { this.spotCode = spotCode.trim().toUpperCase(); }

    public String getSpotId() { return spotId; }

    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level.trim(); }

    public boolean isReserved() { return reserved; }
    public void setReserved(boolean reserved) { this.reserved = reserved; }

    public String getSpotRef() { return spotRef; }

    public static int getCount() { return count; }
    public static void setCount(int count) { ParkingSpot.count = count; }

    /**
     * @return Lab 1.2 style derived ref: first 2 chars of level + last 2 chars of spotId, uppercase
     */
    private String generateSpotRef() {
        String levelPart = "";
        if (level != null && level.length() >= 2) {
            levelPart = level.substring(0, 2);
        }
        String idPart = "";
        if (spotId != null && spotId.length() >= 2) {
            idPart = spotId.substring(spotId.length() - 2);
        }
        return (levelPart + idPart).toUpperCase();
    }

    @Override
    public String toString() {
        return String.format("Spot ID: %s%nSpot Ref: %s%nSpot Code: %s%nLevel: %s%nReserved: %b",
            spotId, spotRef, spotCode, level, reserved);
    }
}

