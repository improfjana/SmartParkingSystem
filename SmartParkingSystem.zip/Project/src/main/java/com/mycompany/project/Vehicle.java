package com.mycompany.project;

public abstract class Vehicle implements ParkingOperations {

    private final String vehicleId;
    private String licensePlate;
    private String ownerName;
    private int parkingHours;
    private String spotId;
    private double minimumFee;
    private ParkingTicket ticket;
    private static int totalVehicles;

    public Vehicle(String vehicleId, String licensePlate, String ownerName, int parkingHours, String spotId, double minimumFee, ParkingTicket ticket) {

        this.vehicleId = vehicleId;
        setLicensePlate(licensePlate);
        setOwnerName(ownerName);
        setParkingHours(parkingHours);
        setSpotId(spotId);
        setMinimumFee(minimumFee);
        setTicket(ticket);
        totalVehicles++;
    }

    // empty constructor
    public Vehicle() {
        this("", "", "", 0, "", 0.0, null);
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate.trim().toUpperCase();
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName.trim();
    }

    public int getParkingHours() {
        return parkingHours;
    }

    public void setParkingHours(int parkingHours) {
        if (parkingHours < 0) {
            throw new IllegalArgumentException("Parking hours cannot be negative");
        }
        this.parkingHours = parkingHours;
    }

    public String getSpotId() {
        return spotId;
    }

    public void setSpotId(String spotId) {
        this.spotId = spotId.trim();
    }

    public double getMinimumFee() {
        return minimumFee;
    }

    public void setMinimumFee(double minimumFee) {
        if (minimumFee < 0) {
            throw new IllegalArgumentException("Minimum fee cannot be negative");
        }
        this.minimumFee = minimumFee;
    }

    public ParkingTicket getTicket() {
        return ticket;
    }

    public void setTicket(ParkingTicket ticket) {
        this.ticket = ticket;
    }

    public static int getTotalVehicles() {
        return totalVehicles;
    }

    public static void setTotalVehicles(int totalVehicles) {
        Vehicle.totalVehicles = totalVehicles;
    }

    public abstract double getParkingRate();

    public abstract String getVehicleType();

    public abstract void showFeatures();

    
    @Override
    public double calculateParkingFee(int hours) {
        if (hours < 0) {
            throw new IllegalArgumentException("Hours cannot be negative");
        }
        double fee = getParkingRate() * hours;
        return fee < minimumFee ? minimumFee : fee;
    }

    @Override
    public String getParkingInfo() {
        return String.format("%s [%s] plate %s, owner %s, spot %s",
                getVehicleType(), vehicleId, licensePlate, ownerName, spotId);
    }

    @Override
    public String toString() {
        return String.format("Vehicle ID: %s%nLicense Plate: %s%nOwner: %s%nParking Hours: %d%nSpot ID: %s%nMinimum Fee: %.2f%nType: %s",
                vehicleId, licensePlate, ownerName, parkingHours, spotId, minimumFee, getVehicleType());
    }
}
