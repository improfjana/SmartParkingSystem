package com.mycompany.project;

 public class ParkingFloor {

    private String floorName;
    private int totalSpots;
    private ParkingSpot[] spots;

     
    public ParkingFloor(String floorName, int totalSpots, ParkingSpot[] spots) {
        setFloorName(floorName);
        setTotalSpots(totalSpots);
        setSpots(spots);
    }

    // empty constructor
    public ParkingFloor() {
        this("", 0, new ParkingSpot[0]);
    }

    public String getFloorName() { return floorName; }
    public void setFloorName(String floorName) { this.floorName = floorName.trim(); }

    public int getTotalSpots() { return totalSpots; }
    public void setTotalSpots(int totalSpots) {
        if (totalSpots < 0) throw new IllegalArgumentException("Total spots cannot be negative");
        this.totalSpots = totalSpots;
    }

    public ParkingSpot[] getSpots() { return spots; }
    public void setSpots(ParkingSpot[] spots) { this.spots = spots; }

    /**
     * @param id spot identifier to look up
     * @return matching ParkingSpot or null if not found
     */
    public ParkingSpot findSpotById(String id) {
        if (spots == null || id == null) {
            return null;
        }
        for (int i = 0; i < spots.length; i++) {
            if (spots[i] != null && spots[i].getSpotId().equalsIgnoreCase(id)) {
                return spots[i];
            }
        }
        return null;
    }

    public String listAvailableSpots() {
        if (spots == null || spots.length == 0) {
            return "No spots in this floor.";
        }
        String result = "";
        for (int i = 0; i < spots.length; i++) {
            if (spots[i] != null && !spots[i].isReserved()) {
                result += spots[i].toString() + "\n------------------------------------------\n";
            }
        }
        if (result.length() == 0) {
            return "No available spots.";
        }
        return result;
    }

    @Override
    public String toString() {
        int actualLen = (spots == null) ? 0 : spots.length;
        return String.format("Floor: %s%nTotal Spots: %d%nSpots Array Length: %d",
            floorName, totalSpots, actualLen);
    }
}

